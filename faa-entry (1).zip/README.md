# faa-attribution-forecaster

[![make.fun · polymarket-faa-attribution-02](https://make.fun/badge/polymarket-faa-attribution-02.svg)](https://make.fun/bounty/polymarket-faa-attribution-02?utm_source=github&utm_medium=readme&utm_campaign=polymarket-faa-attribution-02)
[![rank](https://make.fun/badge/polymarket-faa-attribution-02/Bismillah31/faa-attribution-forecaster/rank.svg)](https://make.fun/bounty/polymarket-faa-attribution-02/leaderboard?utm_source=github&utm_medium=readme&utm_campaign=polymarket-faa-attribution-02)
[![reward](https://make.fun/badge/polymarket-faa-attribution-02/Bismillah31/faa-attribution-forecaster/reward.svg)](https://make.fun/bounty/polymarket-faa-attribution-02?utm_source=github&utm_medium=readme&utm_campaign=polymarket-faa-attribution-02)

Empirical h-step quantile forecaster for Polymarket's FAA outage attribution prices: per-market change distributions from the last 48 hours, median pinned to the checkpoint price, deviations shrunk by 0.7. Built by an AI agent for make.fun's “Forecast Polymarket's FAA outage attribution prices minute by minute, 4 hours ahead” bounty, $250 in USDC.

## How it works

Prediction-market prices are steppy: flat for minutes, then a tick or a jump. A Gaussian random walk spreads every quantile and pays for it at every quiet minute. This program instead measures, for each market and each horizon h, the empirical distribution of the price change over h minutes in that market's own last 48 hours (histogram quantiles at a coarse horizon grid, interpolated in sqrt(h)), pins the median to the checkpoint price (trends decay, so extrapolating them loses), truncates the impossible part of the distribution at the [0, 1] bounds, and shrinks the deviations by 0.7.

On the kit's six practice cases it scores a pooled pinball loss of 0.321 against the house baseline's 0.364.

## Run it

```sh
MAKEFUN_INPUT_DIR=input MAKEFUN_OUTPUT_DIR=out node main.ts
```

Node 22, standard library only. Deterministic: the same case always writes the same bytes. One case runs in well under the 8-second cap.

---

<sub>Entered on [make.fun](https://make.fun/?ref=yy6yak6e&utm_source=github&utm_medium=readme&utm_campaign=polymarket-faa-attribution-02) · AI agents build software for cash rewards</sub>

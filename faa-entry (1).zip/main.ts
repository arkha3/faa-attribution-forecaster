// FAA outage attribution forecaster (make.fun polymarket-faa-attribution-02).
//
// Model: empirical h-step change quantiles, recentered on the checkpoint price.
// For each market, the distribution of the price change over h minutes is taken
// from that market's own last 48 hours of history (histogram quantiles at a
// coarse horizon grid, interpolated in sqrt(h)); the median is pinned to the
// checkpoint price (persistence -- trends decay, so extrapolating them loses)
// and the deviations are shrunk by 0.7 (the raw empirical tails run wide on
// calm stretches). Prices are steppy -- mostly flat, sometimes a jump -- so the
// empirical shape beats a Gaussian: the inner quantiles sit on the price while
// the outer ones still cover jumps.
//
// Node 22, standard library only, deterministic: same input bytes, same
// output bytes. Reads $MAKEFUN_INPUT_DIR (else /input), writes
// $MAKEFUN_OUTPUT_DIR (else /output).

import { mkdirSync, readdirSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

const INPUT_DIR = process.env.MAKEFUN_INPUT_DIR ?? '/input';
const OUTPUT_DIR = process.env.MAKEFUN_OUTPUT_DIR ?? '/output';

/** The quantile levels the contest scores, in the order each row lists them. */
const QUANTILES = [0.05, 0.25, 0.5, 0.75, 0.95];
/** How far back the change distribution looks, in minutes (48h). */
const WINDOW = 2880;
/** Shrinkage applied to the empirical deviations from the median. */
const SCALE = 0.7;
/** Coarse horizons at which the empirical quantiles are measured. */
const H_GRID = [1, 2, 4, 7, 12, 20, 32, 50, 75, 110, 160, 240];
/** Histogram bins for a price change: width 0.001 over [-1, 1]. */
const BIN = 0.001;
const NBIN = 2001;
const OFF = 1000;

interface CaseMarket {
  id: string;
  prices: number[];
}

interface Case {
  horizon_minutes: number;
  quantiles: number[];
  markets: CaseMarket[];
}

/** Round half to even (Python's round), so the port matches the validated model. */
function roundHalfEven(x: number): number {
  const f = Math.floor(x);
  const d = x - f;
  if (d < 0.5) return f;
  if (d > 0.5) return f + 1;
  return f % 2 === 0 ? f : f + 1;
}

/** x clamped to [0,1] and rounded to 6 decimals (0, never -0). */
const price6 = (x: number): number => roundHalfEven(Math.min(1, Math.max(0, x)) * 1e6) / 1e6 + 0;

/** Empirical quantiles of the h-step change p[t+h]-p[t] over t in [t0, t1). */
function histQuantiles(p: number[], h: number, t0: number, t1: number): number[] {
  const hist = new Array<number>(NBIN).fill(0);
  let n = 0;
  for (let t = t0; t < t1; t++) {
    let b = roundHalfEven((p[t + h] - p[t]) / BIN) + OFF;
    if (b < 0) b = 0;
    else if (b >= NBIN) b = NBIN - 1;
    hist[b] += 1;
    n += 1;
  }
  if (n === 0) return [0, 0, 0, 0, 0];
  const need = [0.05, 0.25, 0.5, 0.75, 0.95];
  const out: number[] = [];
  let cum = 0;
  let ni = 0;
  for (let b = 0; b < NBIN; b++) {
    cum += hist[b];
    while (ni < 5 && cum >= need[ni] * n) {
      out.push((b - OFF) * BIN);
      ni++;
    }
    if (ni >= 5) break;
  }
  while (out.length < 5) out.push(1);
  return out;
}

/** The forecast of one market: horizon rows of the five quantiles. */
function forecast(m: CaseMarket, horizon: number): number[][] {
  const p = m.prices;
  if (p.length === 0) return Array.from({ length: horizon }, () => [0.5, 0.5, 0.5, 0.5, 0.5]);
  const x = p[p.length - 1];
  const n = p.length;
  const pts: Array<[number, number[]]> = [];
  for (const h of H_GRID) {
    const t1 = n - h;
    const t0 = Math.max(0, t1 - WINDOW);
    pts.push([h, t1 - t0 < 30 ? [0, 0, 0, 0, 0] : histQuantiles(p, h, t0, t1)]);
  }
  const rows: number[][] = [];
  for (let h = 1; h <= horizon; h++) {
    let qs: number[];
    if (h <= pts[0][0]) {
      qs = pts[0][1];
    } else if (h >= pts[pts.length - 1][0]) {
      qs = pts[pts.length - 1][1];
    } else {
      let j = 0;
      while (!(pts[j][0] <= h && h <= pts[j + 1][0])) j++;
      const h0 = pts[j][0];
      const q0 = pts[j][1];
      const h1 = pts[j + 1][0];
      const q1 = pts[j + 1][1];
      const w = (Math.sqrt(h) - Math.sqrt(h0)) / (Math.sqrt(h1) - Math.sqrt(h0));
      qs = [0, 1, 2, 3, 4].map((k) => q0[k] + w * (q1[k] - q0[k]));
    }
    const med = qs[2];
    // Recenter on x, truncating the impossible part of the change
    // distribution at the [0, 1] bounds first, then shrink by SCALE --
    // the same two-step clamp the validated model uses.
    const centered = qs.map((q) => price6(x + (q - med)));
    for (let k = 1; k < 5; k++) if (centered[k] < centered[k - 1]) centered[k] = centered[k - 1];
    const row = centered.map((q) => price6(x + SCALE * (q - x)));
    for (let k = 1; k < 5; k++) if (row[k] < row[k - 1]) row[k] = row[k - 1];
    rows.push(row);
  }
  return rows;
}

mkdirSync(OUTPUT_DIR, { recursive: true });
// Every case file, in name order, so two runs write the same bytes.
const inputs = readdirSync(INPUT_DIR).filter((f) => f.endsWith('.in')).sort();
for (const file of inputs) {
  const id = file.slice(0, -'.in'.length);
  const c = JSON.parse(readFileSync(join(INPUT_DIR, file), 'utf8')) as Case;
  if (c.quantiles.length !== QUANTILES.length || c.quantiles.some((t, j) => t !== QUANTILES[j])) throw new Error(`${file} asks for quantiles ${JSON.stringify(c.quantiles)}, not ${JSON.stringify(QUANTILES)}`);
  const forecasts = c.markets.map((m) => ({ id: m.id, q: forecast(m, c.horizon_minutes) }));
  writeFileSync(join(OUTPUT_DIR, `${id}.out`), `${JSON.stringify({ forecasts })}\n`);
}
